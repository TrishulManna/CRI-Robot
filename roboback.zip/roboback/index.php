<?php

/*
 * Go to the start of the RobotRental website
 */
 header("Location: /roboback/public/login");